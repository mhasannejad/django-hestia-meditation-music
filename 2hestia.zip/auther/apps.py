from django.apps import AppConfig


class AutherConfig(AppConfig):
    name = 'auther'
